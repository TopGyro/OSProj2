#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <pthread.h>
#include <semaphore.h>

#include "hash_functions.h"

/* Main thread + at most 11 workers => never more than 12 threads. */
#define MAX_WORKERS 11
#define NSLOTS 32

typedef struct {
	unsigned char *data;
	int idx;
} chunk_job_t;

typedef struct {
	chunk_job_t slots[NSLOTS];
	int head;
	int tail;
	sem_t sem_empty;
	sem_t sem_full;
	pthread_mutex_t mutex;
	int chunk_size;
	unsigned char **hashes;
} RingBuffer;

static void ring_push(RingBuffer *rb, unsigned char *data, int idx) {
	sem_wait(&rb->sem_empty);
	pthread_mutex_lock(&rb->mutex);
	rb->slots[rb->tail].data = data;
	rb->slots[rb->tail].idx = idx;
	rb->tail = (rb->tail + 1) % NSLOTS;
	pthread_mutex_unlock(&rb->mutex);
	sem_post(&rb->sem_full);
}

static void *consumer(void *arg) {
	RingBuffer *rb = (RingBuffer *)arg;

	for (;;) {
		sem_wait(&rb->sem_full);
		pthread_mutex_lock(&rb->mutex);
		chunk_job_t job = rb->slots[rb->head];
		rb->head = (rb->head + 1) % NSLOTS;
		pthread_mutex_unlock(&rb->mutex);
		sem_post(&rb->sem_empty);

		if (job.idx < 0)
			break;

		rb->hashes[job.idx] = calculate_sha512(job.data, (unsigned int)rb->chunk_size);
		free(job.data);
	}
	return NULL;
}

typedef struct HashEntry {
	unsigned char *digest;
	struct HashEntry *next;
} HashEntry;

/* FNV-1a 64-bit: bucket index for digest keys (full equality still via memcmp). */
static size_t digest_bucket(const unsigned char *d, int digest_len, size_t nbuckets) {
	uint64_t h = 1469598103934665603ULL;
	for (int i = 0; i < digest_len; i++)
		h = (h ^ (uint64_t)d[i]) * 1099511628211ULL;
	return (size_t)(h % nbuckets);
}

static void hashmap_free_buckets(HashEntry **buckets, size_t nbuckets) {
	for (size_t b = 0; b < nbuckets; b++) {
		HashEntry *e = buckets[b];
		while (e) {
			HashEntry *next = e->next;
			free(e);
			e = next;
		}
	}
	free(buckets);
}

// Function name: dedupe
// Description:   Computes a hash for each chunk of the input file, and the obtained hashes
//                to each other to determine the number of unique chunks in the file
void dedupe(char *filename, int chunk_size, char *output) {
	FILE *fp;
	unsigned char **hashes = NULL;
	int hash_size = size_sha512(), n_hashes = 0;

	// load chunks of the input file and hash them (producer + worker pool)
	RingBuffer rb;
	rb.head = rb.tail = 0;
	rb.chunk_size = chunk_size;
	rb.hashes = NULL;
	assert(sem_init(&rb.sem_empty, 0, NSLOTS) == 0);
	assert(sem_init(&rb.sem_full, 0, 0) == 0);
	assert(pthread_mutex_init(&rb.mutex, NULL) == 0);

	pthread_t workers[MAX_WORKERS];
	for (int w = 0; w < MAX_WORKERS; w++)
		assert(pthread_create(&workers[w], NULL, consumer, &rb) == 0);

	fp = fopen(filename, "rb");
	assert(fp != NULL);
	if (fseek(fp, 0, SEEK_END) != 0) {
		fclose(fp);
		assert(0);
	}
	long fsize = ftell(fp);
	assert(fsize >= 0);
	if (fseek(fp, 0, SEEK_SET) != 0) {
		fclose(fp);
		assert(0);
	}
	n_hashes = (int)(fsize / chunk_size);
	hashes = (unsigned char **)calloc((size_t)n_hashes, sizeof(unsigned char *));
	assert(n_hashes == 0 || hashes != NULL);
	rb.hashes = hashes;

	for (int idx = 0; idx < n_hashes; idx++) {
		unsigned char *chunk = (unsigned char *)malloc((size_t)chunk_size);
		assert(chunk != NULL);
		assert(fread(chunk, 1, (size_t)chunk_size, fp) == (size_t)chunk_size);
		ring_push(&rb, chunk, idx);
	}
	fclose(fp);

	for (int w = 0; w < MAX_WORKERS; w++)
		ring_push(&rb, NULL, -1);

	for (int w = 0; w < MAX_WORKERS; w++)
		pthread_join(workers[w], NULL);

	sem_destroy(&rb.sem_empty);
	sem_destroy(&rb.sem_full);
	pthread_mutex_destroy(&rb.mutex);

	int *mask = (int *)malloc((size_t)(n_hashes > 0 ? n_hashes : 1) * sizeof(int));
	assert(mask != NULL);
	for (int i = 0; i < n_hashes; i++)
		mask[i] = 0;

	/* Duplicate detection: chaining hash map on digest → O(n) average (was O(n²)).
	 * First occurrence stays mask 0; later equal digests get mask 1.
	 * THREADING: this pass is sequential; parallel speedup would need a concurrent
	 * hash map or sharded maps merged by digest—usually not worth it until n is huge. */
	size_t nbuckets = (size_t)n_hashes * 2u + 32u;
	if (nbuckets < 64u)
		nbuckets = 64u;
	HashEntry **buckets = (HashEntry **)calloc(nbuckets, sizeof(HashEntry *));
	assert(buckets != NULL);

	for (int i = 0; i < n_hashes; i++) {
		unsigned char *d = hashes[i];
		size_t b = digest_bucket(d, hash_size, nbuckets);
		HashEntry *e = buckets[b];
		while (e) {
			if (memcmp(e->digest, d, (size_t)hash_size) == 0) {
				mask[i] = 1;
				break;
			}
			e = e->next;
		}
		if (!e) {
			HashEntry *ne = (HashEntry *)malloc(sizeof(HashEntry));
			assert(ne != NULL);
			ne->digest = d;
			ne->next = buckets[b];
			buckets[b] = ne;
		}
	}
	hashmap_free_buckets(buckets, nbuckets);

	// print results
	/* THREADING: Writing the mask is usually left single-threaded (one fprintf
	 * sequence) unless you build the line in a buffer first, then write once. */
	fp = fopen(output, "w");
	assert(fp != NULL);
	for (int i = 0; i < n_hashes; i++)
		fprintf(fp, "%d", mask[i]);
	fprintf(fp, "\n");
	fclose(fp);

	for (int i = 0; i < n_hashes; i++)
		free(hashes[i]);
	free(hashes);
	free(mask);
}
